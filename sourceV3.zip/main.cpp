#include <QApplication>
#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QPushButton>
#include <QLineEdit>
#include <QListView>
#include <QTextEdit>
#include <QFileDialog>
#include <QStandardItemModel>
#include <QStandardItem>
#include <QSortFilterProxyModel>
#include <QTabWidget>
#include <QLabel>
#include <QDirIterator>
#include <QProcess>
#include <QFuture>
#include <QFutureWatcher>
#include <QtConcurrent>
#include <QProgressBar>
#include <cstdarg>
#include <QFileInfo>
#include <QDir>

static QStringList splitCommandLine(const QString &cmd) {
    QStringList out;
    QString cur;
    bool inQuotes = false;
    QChar quoteChar = '"';
    for (int i = 0; i < cmd.size(); ++i) {
        QChar c = cmd[i];
        if ((c == '"' || c == '\'') && (i == 0 || cmd[i-1] != '\\')) {
            if (!inQuotes) { inQuotes = true; quoteChar = c; continue; }
            else if (quoteChar == c) { inQuotes = false; continue; }
        }
        if (c.isSpace() && !inQuotes) {
            if (!cur.isEmpty()) { out << cur; cur.clear(); }
        } else cur.push_back(c);
    }
    if (!cur.isEmpty()) out << cur;
    return out;
}

static QVector<QString> findCompilersInPath() {
    QStringList candidates;
#ifdef Q_OS_WIN
    candidates << "g++.exe" << "g++" << "clang++.exe" << "clang++" << "cl.exe";
#else
    candidates << "g++" << "clang++";
#endif
    QProcessEnvironment env = QProcessEnvironment::systemEnvironment();
    QStringList dirs = env.value("PATH").split(
#ifdef Q_OS_WIN
        ";"
#else
        ":"
#endif
    , Qt::SkipEmptyParts);
    QVector<QString> found;
    for (const QString &d : dirs) {
        QDir dir(d);
        if (!dir.exists()) continue;
        for (const QString &cand : candidates) {
            QFileInfo fi(dir.filePath(cand));
            if (fi.exists() && fi.isFile() && !found.contains(fi.absoluteFilePath()))
                found.push_back(QDir::toNativeSeparators(fi.absoluteFilePath()));
        }
    }
    return found;
}

class CompilerGUI : public QWidget {
    Q_OBJECT
public:
    CompilerGUI(QWidget *parent=nullptr) : QWidget(parent) {
        setWindowTitle("Fast Compiler GUI");
        resize(1000, 700);

        QVBoxLayout *layout = new QVBoxLayout(this);
        QTabWidget *tabs = new QTabWidget();
        layout->addWidget(tabs);

        // --- Project Tab ---
        QWidget *projTab = new QWidget();
        QVBoxLayout *projLayout = new QVBoxLayout(projTab);
        QHBoxLayout *projSel = new QHBoxLayout();
        selectProjectBtn = new QPushButton("Select Project Folder");
        projectPathLabel = new QLabel("<no project>");
        projSel->addWidget(selectProjectBtn);
        projSel->addWidget(projectPathLabel);
        projSel->addStretch();
        projLayout->addLayout(projSel);

        QLabel *srcLabel = new QLabel("Source files:");
        projLayout->addWidget(srcLabel);
        sourcesView = new QListView();
        sourcesModel = new QStandardItemModel(this);
        sourcesView->setModel(sourcesModel);
        sourcesView->setMinimumHeight(150);
        projLayout->addWidget(sourcesView);
        connect(selectProjectBtn, &QPushButton::clicked, this, &CompilerGUI::selectProject);

        tabs->addTab(projTab, "Project");

        // --- Compiler Tab ---
        QWidget *compTab = new QWidget();
        QVBoxLayout *compLayout = new QVBoxLayout(compTab);
        QLabel *compLabel = new QLabel("Detected compilers:");
        compLayout->addWidget(compLabel);
        compilersList = new QListView();
        compilersModel = new QStandardItemModel(this);
        compilersList->setModel(compilersModel);
        compLayout->addWidget(compilersList);

        compileCmdEdit = new QLineEdit();
        compileCmdEdit->setPlaceholderText("Compiler command + flags");
        compLayout->addWidget(compileCmdEdit);
        tabs->addTab(compTab, "Compiler");

        auto comps = findCompilersInPath();
        for (const QString &p : comps) compilersModel->appendRow(new QStandardItem(p));

        connect(compilersList, &QListView::clicked, this, [=](const QModelIndex &idx){
            if (!idx.isValid()) return;
            QString compilerPath = compilersModel->item(idx.row())->text();
            QString quoted = compilerPath.contains(' ') ? QString("\"%1\"").arg(compilerPath) : compilerPath;
            compileCmdEdit->setText(quoted + (compilerPath.endsWith("cl.exe", Qt::CaseInsensitive) ? " /nologo /EHsc" : " -Wall -O2"));
        });

        // --- Libraries Tab ---
        QWidget *libTab = new QWidget();
        QVBoxLayout *libLayout = new QVBoxLayout(libTab);
        QHBoxLayout *libsBtnLayout = new QHBoxLayout();
        QPushButton *addLibFolderBtn = new QPushButton("Add Folder");
        QPushButton *removeLibFolderBtn = new QPushButton("Remove Selected");
        libsBtnLayout->addWidget(addLibFolderBtn);
        libsBtnLayout->addWidget(removeLibFolderBtn);
        libsBtnLayout->addStretch();
        libLayout->addLayout(libsBtnLayout);

        libDirsView = new QListView();
        libDirsModel = new QStandardItemModel(this);
        libDirsView->setModel(libDirsModel);
        libDirsView->setMinimumHeight(150);
        libLayout->addWidget(libDirsView);

        searchLibs = new QLineEdit();
        searchLibs->setPlaceholderText("Search libraries...");
        libLayout->addWidget(searchLibs);

        libsView = new QListView();
        model = new QStandardItemModel(this);
        proxyModel = new QSortFilterProxyModel(this);
        proxyModel->setSourceModel(model);
        proxyModel->setFilterCaseSensitivity(Qt::CaseInsensitive);
        proxyModel->setFilterKeyColumn(0);
        libsView->setModel(proxyModel);
        libsView->setMinimumHeight(200);
        libLayout->addWidget(libsView);

        progressBar = new QProgressBar();
        progressBar->setRange(0,0);
        progressBar->setVisible(false);
        libLayout->addWidget(progressBar);

        connect(addLibFolderBtn, &QPushButton::clicked, this, &CompilerGUI::selectLibFolder);
        connect(removeLibFolderBtn, &QPushButton::clicked, this, &CompilerGUI::removeSelectedLibFolder);
        connect(searchLibs, &QLineEdit::textChanged, proxyModel, &QSortFilterProxyModel::setFilterFixedString);

        tabs->addTab(libTab, "Libraries");

        // --- Bottom buttons and output ---
        QHBoxLayout *buttons = new QHBoxLayout();
        compileBtn = new QPushButton("Compile");
        QPushButton *clearOutputBtn = new QPushButton("Clear Output");
        buttons->addWidget(compileBtn);
        buttons->addWidget(clearOutputBtn);
        buttons->addStretch();
        layout->addLayout(buttons);

        output = new QTextEdit();
        output->setReadOnly(true);
        output->setMinimumHeight(200);
        layout->addWidget(output);

        connect(compileBtn, &QPushButton::clicked, this, &CompilerGUI::compileProject);
        connect(clearOutputBtn, &QPushButton::clicked, output, &QTextEdit::clear);

#ifdef Q_OS_LINUX
        addLibraryFolderAsync("/usr/local");
#endif
    }

private slots:
    void selectProject() {
        QString folder = QFileDialog::getExistingDirectory(this, "Select Project Folder");
        if (folder.isEmpty()) return;
        projectPath = folder;
        projectPathLabel->setText(projectPath);
        sourcesModel->clear();
        QDir dir(folder);
        QStringList files = dir.entryList(QStringList() << "*.c" << "*.cpp" << "*.cc" << "*.cxx", QDir::Files);
        for (const QString &f : files) {
            QStandardItem *item = new QStandardItem(f);
            item->setCheckable(true);
            item->setCheckState(Qt::Checked);
            sourcesModel->appendRow(item);
        }
    }

    void selectLibFolder() {
        QString folder = QFileDialog::getExistingDirectory(this, "Select Library Folder");
        if (folder.isEmpty()) return;

        progressBar->setVisible(true);

        // Фоновый поток сканирования
        QFuture<QStringList> future = QtConcurrent::run([folder](){
            QStringList files;
            QDirIterator it(folder, QStringList() << "*.h" << "*.hpp" << "*.a" << "*.so", 
                            QDir::Files, QDirIterator::Subdirectories);
            while (it.hasNext()) files << it.next();
            return files;
        });

        QFutureWatcher<QStringList> *watcher = new QFutureWatcher<QStringList>(this);
        connect(watcher, &QFutureWatcher<QStringList>::finished, this, [=]() {
            QStringList files = watcher->future().result();

            // Добавляем элементы партиями
            int batchSize = 50;
            for (int start = 0; start < files.size(); start += batchSize) {
                int end = qMin(start + batchSize, files.size());
                for (int i = start; i < end; ++i) {
                    QStandardItem *item = new QStandardItem(files[i]);
                    item->setCheckable(true);
                    item->setCheckState(Qt::Unchecked);
                    model->appendRow(item);
                }
                QApplication::processEvents(); // даём GUI отрисоваться
            }

            progressBar->setVisible(false);
            watcher->deleteLater();
        });
        watcher->setFuture(future);
    }



    void removeSelectedLibFolder() {
        QModelIndex idx = libDirsView->currentIndex();
        if (!idx.isValid()) return;
        QString folder = libDirsModel->item(idx.row())->text();
        for (int i = model->rowCount()-1; i >= 0; --i)
            if (model->item(i)->text().startsWith(folder)) model->removeRow(i);
        libDirsModel->removeRow(idx.row());
    }

    void compileProject() {
        if (projectPath.isEmpty()) { output->append("Select project first."); return; }

        QStringList sources;
        for (int i=0; i<sourcesModel->rowCount(); ++i)
            if (sourcesModel->item(i)->checkState() == Qt::Checked)
                sources << QDir(projectPath).filePath(sourcesModel->item(i)->text());

        if (sources.isEmpty()) { output->append("No sources selected."); return; }

        QString cmdLine = compileCmdEdit->text().trimmed();
        if (cmdLine.isEmpty()) { output->append("No compiler selected."); return; }

        QStringList tokens = splitCommandLine(cmdLine);
        if (tokens.isEmpty()) { output->append("Bad compiler command."); return; }

        QString program = tokens.takeFirst();
        if ((program.startsWith("\"") && program.endsWith("\"")) ||
            (program.startsWith("'") && program.endsWith("'")))
            program = program.mid(1, program.length()-2);

        QStringList args = tokens;
#ifdef Q_OS_WIN
        QString outFile = QDir(projectPath).filePath("output.exe");
#else
        QString outFile = QDir(projectPath).filePath("output");
#endif
        args << "-o" << QDir::toNativeSeparators(outFile);
        args << sources;

        // --- Libraries ---
        for (int i=0; i<model->rowCount(); ++i) {
            QStandardItem *item = model->item(i);
            if (item->checkState() != Qt::Checked) continue;
            QFileInfo fi(item->text());
            QString dir = QDir::toNativeSeparators(fi.absolutePath());

            if (fi.suffix().toLower() == "h") args << "-I" + dir;
#ifdef Q_OS_WIN
            if (fi.suffix().toLower() == "lib" || fi.suffix().toLower() == "dll") {
                QString libName = fi.completeBaseName();
                args << "-L" + dir << "-l" + libName;
            }
#else
            if (fi.suffix().toLower() == "a" || fi.suffix().toLower() == "so") {
                QString libName = fi.completeBaseName();
                if (libName.startsWith("lib")) libName = libName.mid(3);
                args << "-L" + dir << "-l" + libName;
            }
#endif
        }

        QProcess process;
        process.setProgram(program);
        process.setArguments(args);

        output->append(QString("Running: %1 %2\n").arg(program, args.join(' ')));

        process.start();
        if (!process.waitForStarted(3000)) { output->append("Failed to start compiler."); return; }
        process.waitForFinished(-1);

        QString stdoutStr = process.readAllStandardOutput();
        QString stderrStr = process.readAllStandardError();
        output->append(stdoutStr);
        output->append(stderrStr);

        // Undefined reference hints
        for (const QString &line : stderrStr.split("\n")) {
            if (line.contains("undefined reference") || line.contains("unresolved external symbol")) {
                QString func = line.section('`', 1, 1);
                output->append("\n[!] Function `" + func + "` not found. Maybe forgot to link a library.\n");
            }
        }
    }

private:
    void addLibraryFolderAsync(const QString &folder) {
        if (folder.isEmpty()) return;

        // Добавляем в список директорий
        bool exists = false;
        for (int i=0; i<libDirsModel->rowCount(); ++i)
            if (libDirsModel->item(i)->text() == folder) { exists = true; break; }
        if (!exists) {
            QStandardItem *it = new QStandardItem(folder);
            it->setCheckable(true);
            it->setCheckState(Qt::Checked);
            libDirsModel->appendRow(it);
        }

        // Асинхронная загрузка
        progressBar->setVisible(true);
        QFuture<QStringList> future = QtConcurrent::run([folder](){
            QStringList files;
            QDirIterator it(folder, QStringList() << "*.h" << "*.hpp" << "*.a" << "*.so"
#ifdef Q_OS_WIN
            << "*.lib" << "*.dll"
#endif
            , QDir::Files, QDirIterator::Subdirectories);
            while (it.hasNext()) files << it.next();
            return files;
        });

        QFutureWatcher<QStringList> *watcher = new QFutureWatcher<QStringList>(this);
        connect(watcher, &QFutureWatcher<QStringList>::finished, this, [=]() {
            QStringList files = watcher->future().result();
            for (const QString &f : files) {
                bool dup = false;
                for (int i = 0; i < model->rowCount(); ++i)
                    if (model->item(i)->text() == f) { dup = true; break; }
                if (!dup) {
                    QStandardItem *item = new QStandardItem(f);
                    item->setCheckable(true);
                    item->setCheckState(Qt::Unchecked);
                    model->appendRow(item);
                }
            }
            progressBar->setVisible(false);
            watcher->deleteLater();
        });
        watcher->setFuture(future);
    }


private:
    QString projectPath;
    QPushButton *selectProjectBtn;
    QLabel *projectPathLabel;
    QListView *sourcesView;
    QStandardItemModel *sourcesModel;

    QLineEdit *compileCmdEdit;
    QListView *libDirsView;
    QStandardItemModel *libDirsModel;
    QLineEdit *searchLibs;
    QListView *libsView;
    QStandardItemModel *model;
    QSortFilterProxyModel *proxyModel;
    QPushButton *compileBtn;
    QTextEdit *output;
    QListView *compilersList;
    QStandardItemModel *compilersModel;
    QProgressBar *progressBar;
};

#include "main.moc"

int main(int argc, char *argv[]) {
    QApplication a(argc, argv);
    CompilerGUI w;
    w.show();
    return a.exec();
}
